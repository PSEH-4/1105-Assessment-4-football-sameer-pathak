package com.sapient.assessment4.controller;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.sapient.assessment4.model.Country;
import com.sapient.assessment4.model.League;
import com.sapient.assessment4.model.Standing;

@RestController
public class MatchController {

	@Autowired
	private RestTemplate restTemplate;

	public static final String countryUrl = "https://apiv2.apifootball.com/?action=get_countries&APIkey=9bb66184e0c8145384fd2cc0f7b914ada57b4e8fd2e4d6d586adcc27c257a978";
	public static final String leagueUri = "https://apiv2.apifootball.com/?action=get_leagues&country_id=41&APIkey=9bb66184e0c8145384fd2cc0f7b914ada57b4e8fd2e4d6d586adcc27c257a978";
	public static final String standingUri = "https://apiv2.apifootball.com/?action=get_standings&league_id=148&APIkey=9bb66184e0c8145384fd2cc0f7b914ada57b4e8fd2e4d6d586adcc27c257a978";

	//Takes required input as Country Name, League name, Team name
	@RequestMapping(value = "/football/countryName/{countryName}/leagueName/{leagueName}/teamName/{teamName}", method = RequestMethod.GET)
	public Standing getMatchDetails(@PathVariable @NotBlank String countryName,
			@PathVariable @NotBlank String leagueName, @PathVariable @NotBlank String teamName) {
		System.out.println(countryName + " : " + leagueName + " : " + teamName);
		return orchestrator(countryName, leagueName, teamName);

	}

	// Return the Standing with respect to League Id
	private List<Standing> getStanding(Long leagueId) {

		String standingUrl = "https://apiv2.apifootball.com/?action=get_standings&league_id=" + leagueId
				+ "&APIkey=9bb66184e0c8145384fd2cc0f7b914ada57b4e8fd2e4d6d586adcc27c257a978";
		ResponseEntity<List<Standing>> transResponse = getRestTemplate().exchange(standingUrl, HttpMethod.GET,
				getEntity(), new ParameterizedTypeReference<List<Standing>>() {
				});

		List<Standing> standing = transResponse.getBody();
		return standing;

	}

	// Return the League with respect to Country Id
	private List<League> getLeagues(Long id) {

		String leagueUriCountryId = "https://apiv2.apifootball.com/?action=get_leagues&country_id=" + id
				+ "&APIkey=9bb66184e0c8145384fd2cc0f7b914ada57b4e8fd2e4d6d586adcc27c257a978";
		ResponseEntity<List<League>> transResponse = getRestTemplate().exchange(leagueUriCountryId, HttpMethod.GET,
				getEntity(), new ParameterizedTypeReference<List<League>>() {
				});

		List<League> countries = transResponse.getBody();
		return countries;
	}

	@RequestMapping(value = "/countries", method = RequestMethod.GET)
	private List<Country> getCountries() {

		ResponseEntity<List<Country>> transResponse = getRestTemplate().exchange(countryUrl, HttpMethod.GET,
				getEntity(), new ParameterizedTypeReference<List<Country>>() {
				});

		List<Country> countries = transResponse.getBody();
		return countries;

	}

	/*
	 * The Orchestrator method to manage different API calls 
	 * 1> Get List of Countries and filter it with Country name
	 * 2> Fetch Country ID from previous call and get League Object Filter it with League Name
	 * 3> Get Standing object with respect to league Id from previous call filter it with team Name
	 */
	
	private Standing orchestrator(String countryName, String leagueName, String teamName) {

		List<Country> countries = getCountries();

		List<Country> filteredCountry = countries.stream()
				.filter(empl -> empl.getCountry_name().equalsIgnoreCase(countryName)).collect(Collectors.toList());

		if (filteredCountry != null) {

			List<League> leagues = getLeagues(filteredCountry.get(0).getCountry_id());

			List<League> filteredLeagues = leagues.stream()
					.filter(empl -> empl.getLeague_name().equalsIgnoreCase(leagueName)).collect(Collectors.toList());

			if (filteredLeagues != null) {
				List<Standing> standings = getStanding(filteredLeagues.get(0).getLeague_id());

				if (standings != null) {
					List<Standing> filteredstandings = standings.stream()
							.filter(empl -> empl.getTeam_name().equalsIgnoreCase(teamName))
							.collect(Collectors.toList());
					if (filteredstandings != null) {

						filteredstandings.get(0).setCountry_id(filteredCountry.get(0).getCountry_id());
						return filteredstandings.get(0);
					}
				}
			}
		}
		return null;

	}

	private HttpEntity<String> getEntity() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		return entity;
	}

	public RestTemplate getRestTemplate() {
		return restTemplate;
	}

	public void setRestTemplate(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

}
