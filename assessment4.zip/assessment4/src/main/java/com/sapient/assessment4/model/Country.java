package com.sapient.assessment4.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

// Note: Used values of Json as it is to reduce the typing time, In Prod scenario variables would be camel casing
@JsonIgnoreProperties(ignoreUnknown = true)
public class Country implements Serializable{
	private static final long serialVersionUID = 1L;
	private Long country_id;
	public Long getCountry_id() {
		return country_id;
	}
	public void setCountry_id(Long country_id) {
		this.country_id = country_id;
	}
	public String getCountry_name() {
		return country_name;
	}
	public void setCountry_name(String country_name) {
		this.country_name = country_name;
	}
	private String country_name;
	
//	"country_id": "41",
//	"country_name": "England"

}
