package com.sapient.assessment4.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
//Note: Used values of Json as it is to reduce the typing time, In Prod scenario variables would be camel casing
@JsonIgnoreProperties(ignoreUnknown = true)
public class League implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long country_id;
	private String country_name;
	private Long league_id;
	private String league_name;

	public Long getCountry_id() {
		return country_id;
	}

	public void setCountry_id(Long country_id) {
		this.country_id = country_id;
	}

	public String getCountry_name() {
		return country_name;
	}

	public void setCountry_name(String country_name) {
		this.country_name = country_name;
	}

	public Long getLeague_id() {
		return league_id;
	}

	public void setLeague_id(Long league_id) {
		this.league_id = league_id;
	}

	public String getLeague_name() {
		return league_name;
	}

	public void setLeague_name(String league_name) {
		this.league_name = league_name;
	}

//	"country_id": "41",
//    "country_name": "England",
//    "league_id": "149",
//    "league_name": "Championship"

}
