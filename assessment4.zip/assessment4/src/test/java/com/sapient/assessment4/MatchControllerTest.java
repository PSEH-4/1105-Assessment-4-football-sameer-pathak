package com.sapient.assessment4;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.sapient.assessment4.model.Standing;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Assessment4Application.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class MatchControllerTest {

	@Autowired
	private TestRestTemplate restTemplate;

	@LocalServerPort
	private int port;

	private String getRootUrl() {
		return "http://localhost:" + port;
	}
	
	@Test
	public void testGetStanding() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);

		ResponseEntity<Standing> response = restTemplate.exchange(getRootUrl() + "/football/countryName/England/leagueName/Championship/teamName/Leeds",
				HttpMethod.GET, entity, Standing.class);		
		assertNotNull(response.getBody());
	}
	
	@Test
	public void testGetStandingTeamFulham() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);

		ResponseEntity<Standing> response = restTemplate.exchange(getRootUrl() + "/football/countryName/England/leagueName/Championship/teamName/Fulham",
				HttpMethod.GET, entity, Standing.class);		
		assertNotNull(response.getBody());
	}
	
	@Test
	public void testGetStandingTeamFulhamCheckValue() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);

		ResponseEntity<Standing> response = restTemplate.exchange(getRootUrl() + "/football/countryName/England/leagueName/Championship/teamName/Fulham",
				HttpMethod.GET, entity, Standing.class);		
		assertNotNull(response.getBody());
		
		assertEquals(2639, response.getBody().getTeam_id());
		assertEquals(149, response.getBody().getLeague_id());
		assertEquals(41, response.getBody().getCountry_id());
	}
}
